import { useState } from "react";

function App() {
  const questions = [
    {
      question: "What is 5 + 5?",
      options: ["5", "10", "15", "20"],
      answer: "10"
    },
    {
      question: "Capital of India?",
      options: ["Delhi", "Mumbai", "Chennai", "Kolkata"],
      answer: "Delhi"
    },
    {
      question: "HTML stands for?",
      options: [
        "Hyper Text Markup Language",
        "High Text Machine Language",
        "Home Tool Markup Language",
        "None"
      ],
      answer: "Hyper Text Markup Language"
    }
  ];

  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  function handleClick(option) {
    if (option === questions[current].answer) {
      setScore(score + 1);
    }

    const next = current + 1;

    if (next < questions.length) {
      setCurrent(next);
    } else {
      setFinished(true);
    }
  }

  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h1>Quiz App</h1>

      {finished ? (
        <h2>Your Score: {score} / {questions.length}</h2>
      ) : (
        <>
          <h2>{questions[current].question}</h2>

          {questions[current].options.map((option, index) => (
            <div key={index}>
              <button
                onClick={() => handleClick(option)}
                style={{ margin: "10px", padding: "10px 20px" }}
              >
                {option}
              </button>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

export default App;